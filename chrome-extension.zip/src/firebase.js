import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, RecaptchaVerifier, signInWithPhoneNumber, PhoneAuthProvider, signInWithPopup } from 'firebase/auth';

const firebaseConfig = {
    apiKey: "AIzaSyCTomWUYplapwg7w4eW3uhIcrphyvmi3V8",
    authDomain: "todo-extension-79735.firebaseapp.com",
    projectId: "todo-extension-79735",
    storageBucket: "todo-extension-79735.appspot.com",
    messagingSenderId: "329909071365",
    appId: "1:329909071365:web:813c8d9346052e83c1b66c"
  };

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

const googleProvider = new GoogleAuthProvider();

const createRecaptchaVerifier = () => {
  return new RecaptchaVerifier('recaptcha-container', {
    'size': 'invisible'
  }, auth);
};

export { auth, googleProvider, createRecaptchaVerifier, signInWithPhoneNumber, signInWithPopup, PhoneAuthProvider };
