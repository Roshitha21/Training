import React, { useState, useEffect } from 'react';
import './App.css'; 

function App() {
  const [notes, setNotes] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [priority, setPriority] = useState('low'); // Default priority

  useEffect(() => {
    const savedNotes = localStorage.getItem('notes');
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);

  const handleChange = (event) => {
    setInputValue(event.target.value);
  };

  const handlePriorityChange = (event) => {
    setPriority(event.target.value);
  };

  const handleSaveNote = () => {
    if (inputValue.trim() !== '') {
      const newNote = {
        text: inputValue,
        priority: priority
      };
      const newNotes = [...notes, newNote];
      setNotes(newNotes);
      localStorage.setItem('notes', JSON.stringify(newNotes));
      setInputValue('');
    }
  };

  const handleDeleteNote = (index) => {
    const newNotes = [...notes];
    newNotes.splice(index, 1);
    setNotes(newNotes);
    localStorage.setItem('notes', JSON.stringify(newNotes));
  };

  return (
    <div className="container">
      <h1 className="title">Quick Notes</h1>
      <div className="input-container">
        <input
          type="text"
          value={inputValue}
          onChange={handleChange}
          placeholder="Enter your note"
          className="input-field"
        />
        <select value={priority} onChange={handlePriorityChange} className="priority-select">
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
        </select>
        <button onClick={handleSaveNote} className="btn">Save</button>
      </div>
      <ul className="notes-list">
        {notes.map((note, index) => (
          <li key={index} className="note-item">
            <span className={`note-text ${note.priority}`}>{note.text}</span>
            <span className={`priority-tag ${note.priority}`}>{note.priority}</span>
            <button onClick={() => handleDeleteNote(index)} className="delete-btn">Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;

// import React, { useState, useEffect } from 'react';
// import './App.css';
// import { auth, googleProvider, signInWithPopup } from './firebase';

// function App() {
//   const [user, setUser] = useState(null);
//   const [notes, setNotes] = useState([]);
//   const [inputValue, setInputValue] = useState('');
//   const [priority, setPriority] = useState('low');

//   useEffect(() => {
//     const savedNotes = localStorage.getItem('notes');
//     if (savedNotes) {
//       setNotes(JSON.parse(savedNotes));
//     }
//   }, []);

//   const handleGoogleLogin = () => {
//     signInWithPopup(auth, googleProvider).then(result => {
//       setUser(result.user);
//     }).catch(error => {
//       console.error(error);
//     });
//   };

//   const handleChange = (event) => {
//     setInputValue(event.target.value);
//   };

//   const handlePriorityChange = (event) => {
//     setPriority(event.target.value);
//   };

//   const handleSaveNote = () => {
//     if (inputValue.trim() !== '') {
//       const newNote = {
//         text: inputValue,
//         priority: priority
//       };
//       const newNotes = [...notes, newNote];
//       setNotes(newNotes);
//       localStorage.setItem('notes', JSON.stringify(newNotes));
//       setInputValue('');
//     }
//   };

//   const handleDeleteNote = (index) => {
//     const newNotes = [...notes];
//     newNotes.splice(index, 1);
//     setNotes(newNotes);
//     localStorage.setItem('notes', JSON.stringify(newNotes));
//   };

//   return (
//     <div className="container">
//       <h1 className="title">Quick Notes</h1>
//       {!user ? (
//         <div className="auth-container">
//           <button onClick={handleGoogleLogin} className="btn">Login with Google</button>
//           <div id="recaptcha-container"></div>
//         </div>
//       ) : (
//         <div>
//           <div className="input-container">
//             <input
//               type="text"
//               value={inputValue}
//               onChange={handleChange}
//               placeholder="Enter your note"
//               className="input-field"
//             />
//             <select value={priority} onChange={handlePriorityChange} className="priority-select">
//               <option value="low">Low</option>
//               <option value="medium">Medium</option>
//               <option value="high">High</option>
//             </select>
//             <button onClick={handleSaveNote} className="btn">Save</button>
//           </div>
//           <ul className="notes-list">
//             {notes.map((note, index) => (
//               <li key={index} className="note-item">
//                 <span className={`note-text ${note.priority}`}>{note.text}</span>
//                 <span className={`priority-tag ${note.priority}`}>{note.priority}</span>
//                 <button onClick={() => handleDeleteNote(index)} className="delete-btn">Delete</button>
//               </li>
//             ))}
//           </ul>
//         </div>
//       )}
//     </div>
//   );
// }

// export default App;
