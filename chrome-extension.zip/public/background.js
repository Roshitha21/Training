chrome.runtime.onInstalled.addListener(() => {
    console.log("Extension Installed");
  });
  
  chrome.browserAction.onClicked.addListener(() => {
    console.log("Browser Action Clicked");
  });
  